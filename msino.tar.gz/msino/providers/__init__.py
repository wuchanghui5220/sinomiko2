# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/__init__.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.
"""
pass
# okay decompiling /opt/neo//providers/common/bin/providers/__init__.pyc
