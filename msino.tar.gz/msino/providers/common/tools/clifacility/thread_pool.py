# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/thread_pool.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 27, 2015
"""
from Queue import Queue
import threading, time
from providers.common.tools.clifacility import g_logger, singleton

class ThreadContext(object):
    """
    Thread context
    """

    def __init__(self, name, result_callback, func, args, kwargs):
        self.name = name
        self.result_callback = result_callback
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def call(self):
        try:
            result = self.func(*self.args, **self.kwargs)
            success = True
        except Exception as e:
            result = e
            success = False

        if self.result_callback:
            try:
                self.result_callback(result, success)
            except Exception as e:
                g_logger.error('Thread context got and exception while running result callback: %s', str(e))


class KillableThread(threading.Thread):

    def __init__(self, target, name, args=(), kwargs=None):
        super(KillableThread, self).__init__(target=target, name=name, args=args, kwargs=kwargs)
        self._killed = False
        self.daemon = True
        self._lastCall = None
        self._ct_name = None
        return

    def kill(self):
        self._killed = True

    def isKilled(self):
        return self._killed

    def setContext(self, ct_name):
        self._lastCall = time.time()
        self._ct_name = ct_name

    def clearContext(self):
        self._lastCall = None
        self._ct_name = None
        return

    def getLastCall(self):
        return self._lastCall

    def getContextName(self):
        return self._ct_name


@singleton
class ThreadPool(object):
    """
    Thread pool
    """

    def __init__(self):
        self._stopped = False
        self._threads = []
        self._queue = Queue()

    def start(self, pool_size):
        g_logger.info('Starting thread pool: size=%s', pool_size)
        for i in xrange(1, pool_size + 1):
            thread_obj = KillableThread(target=self._threadMain, name='thread-%d' % i)
            self._threads.append(thread_obj)

        for thread_obj in self._threads:
            thread_obj.start()

    def stop(self):
        if self._stopped:
            return
        self._stopped = True
        thread_count = len(self._threads)
        while thread_count:
            self._queue.put(None, block=False)
            thread_count -= 1

        for th in self._threads:
            if not th.isKilled():
                th.join()

        g_logger.info('Stopping thread pool')
        return

    def callThread(self, ct_name, result_callback, func, *args, **kw):
        if self._stopped:
            return
        context = ThreadContext(ct_name, result_callback, func, args, kw)
        self._queue.put(context, block=False)

    def _threadMain(self):
        context = self._queue.get()
        while context is not None:
            ct = threading.currentThread()
            ct.setContext(context.name)
            context.call()
            ct.clearContext()
            context = self._queue.get()

        return

    def killTimedoutThreads(self, timeout):
        curr_time = time.time()
        killed_list = []
        for th in self._threads:
            last_call = th.getLastCall()
            if not last_call:
                continue
            if last_call + timeout < curr_time:
                ct_name = th.getContextName()
                killed_list.append(ct_name)
                th.kill()
                th.clearContext()
                g_logger.warning('Killing thread for context: %s', ct_name)

        return killed_list
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/thread_pool.pyc
