# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/kerberos_ticket.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Gal Sivan
@date:   Feb 16, 2015
"""
from providers.common.tools.clifacility import g_logger
from providers.common.tools.clifacility.cmd import BashCommand, CommandResult
import datetime

class KerberosTicket(object):
    KRB_TICKET_VALID = 0
    KRB_TICKET_INVALID = 1

    def __init__(self, username, password):
        self.password = password
        self.username, self.realm = username.split('@')

    def _checkTicket(self):
        g_logger.debug('Running kerberos _checkTicket')
        cmd_args = ['klist']
        cmd = BashCommand(cmd_args)
        result = cmd.run()
        if result.returncode == 0:
            rlm = self.realm.upper() + '@' + self.realm.upper()
            for line in str(result.stdout).splitlines():
                if line.find(rlm) != -1:
                    parts = line.split()
                    if len(parts) == 5:
                        m, d, y = parts[2].split('/')
                        H, M, S = parts[3].split(':')
                        now = datetime.datetime.now()
                        expires = datetime.datetime(int(y), int(m), int(d), int(H), int(M), int(S))
                        if now > expires:
                            return self.KRB_TICKET_INVALID
                        return self.KRB_TICKET_VALID

        return self.KRB_TICKET_INVALID

    def setTicket(self):
        g_logger.debug('Running kerberos setTicket')
        if self._checkTicket() == self.KRB_TICKET_INVALID:
            g_logger.debug('setting new kerberos ticket')
            auth = self.username + '@' + self.realm.upper()
            cmd_args = ['kinit', '-l', '7d', '-r', '7d', '-pAf', auth]
            cmd = BashCommand(cmd_args)
            return cmd.runStdIn(self.password)
        return CommandResult(0, None, None)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/kerberos_ticket.pyc
