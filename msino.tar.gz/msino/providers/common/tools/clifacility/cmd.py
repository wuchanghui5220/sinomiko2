# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/cmd.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Jan 24, 2016
"""
import subprocess32 as subprocess
from providers.common.tools.clifacility import g_logger

class CommandResult(object):

    def __init__(self, returncode, stdout, stderr):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


class BashCommand(object):

    def __init__(self, command_line):
        self.command_line = command_line

    def run(self):
        p = subprocess.Popen(self.command_line, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
        stdout, stderr = p.communicate()
        g_logger.debug('BashCommand.run rc: %d', p.returncode)
        g_logger.debug('BashCommand.run stdout: %s', stdout)
        g_logger.debug('BashCommand.run stderr: %s', stderr)
        return CommandResult(p.returncode, stdout, stderr)

    def runStdIn(self, input):
        p = subprocess.Popen(self.command_line, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
        p.stdin.write('%s\n' % input)
        stdout, stderr = p.communicate()
        g_logger.debug('BashCommand.runStdIn rc: %d', p.returncode)
        g_logger.debug('BashCommand.runStdIn stdout: %s', stdout)
        g_logger.debug('BashCommand.runStdIn stderr: %s', stderr)
        return CommandResult(p.returncode, stdout, stderr)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/cmd.pyc
