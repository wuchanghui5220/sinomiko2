# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/arg_parser.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 27, 2015
"""
import argparse, os
from providers.common.tools.clifacility import CommandType, DEFAULT_LOG_DIR

class CommandArgs(object):

    def __init__(self, args):
        if args.commands:
            self.command_type = CommandType.COMMAND
            self.command_value = args.commands
        else:
            if args.file:
                self.command_type = CommandType.FILE
                self.command_value = args.file
            else:
                if args.directory:
                    if args.directory_content == 'systype':
                        self.command_type = CommandType.DIR_TYPE
                    else:
                        self.command_type = CommandType.DIR_HOST
                    self.command_value = args.directory


class EpilogueArgs(object):

    def __init__(self, args):
        self.epilogue = args.epilogue or args.epilogue_suffix or args.epilogue_file
        self.is_suffix = bool(args.epilogue_suffix)
        self.is_file = bool(args.epilogue_file)
        self.executable = args.epilogue_exec


class ExtraCommandsArgs(object):

    def __init__(self, commands, commands_file):
        self.extra_commands = commands or commands_file
        self.is_file = bool(commands_file)


class IntRangeType(object):

    def __init__(self, min_val=0, max_val=None):
        self._min_val = min_val
        self._max_val = max_val
        if max_val is None:
            self._range = ("Value must be greater than: '{0}'").format(self._min_val)
        else:
            self._range = ("Value must be between '{0}' - '{1}'").format(self._min_val, self._max_val)
        return

    def __call__(self, int_val):
        try:
            int_val = int(int_val)
        except:
            raise argparse.ArgumentTypeError(('{0} is not an integer').format(int_val))

        if int_val < self._min_val:
            raise argparse.ArgumentTypeError(('{0} is not in range: {1}').format(int_val, self._range))
        if self._max_val is not None and int_val > self._max_val:
            raise argparse.ArgumentTypeError(('{0} is not in range: {1}').format(int_val, self._range))
        return int_val

    def __repr__(self):
        max_val = self._max_val or ''
        return '%s - %s' % (self._min_val, max_val)


class _DirTypeAction(argparse.Action):

    def __call__(self, parser, namespace, values, option_string=None):
        prospective_dir = values
        if not os.path.isdir(prospective_dir):
            raise argparse.ArgumentTypeError(('{0}:{1} is not a valid path').format('DirTypeAction', prospective_dir))
        if os.access(prospective_dir, os.R_OK):
            setattr(namespace, self.dest, prospective_dir)
        else:
            raise argparse.ArgumentTypeError(('{0}:{1} is not a readable dir').format('DirTypeAction', prospective_dir))


class CliArgParser(object):

    def __init__(self):
        self.args = self._parseArgs()

    def _parseArgs(self):
        try:
            parser = argparse.ArgumentParser()
            parser.add_argument('-s', '--hosts', help='csv file contains hosts data', type=argparse.FileType(), required=True)
            parent_group = parser.add_argument_group('commands', 'commands arguments')
            commands_group = parent_group.add_mutually_exclusive_group(required=True)
            commands_group.add_argument('-c', '--commands', help='commands list')
            commands_group.add_argument('-f', '--file', type=argparse.FileType(), help='commands file')
            commands_group.add_argument('-d', '--directory', action=_DirTypeAction, help='commands directory: contains command files according  to --directory-content argument')
            parent_group.add_argument('-t', '--directory-content', action='store', choices=[
             'systype', 'host'], help='commands directory content type, relevant only when using --dir')
            epilog_group = parser.add_argument_group('epilogue', 'epilogue to be executed after the commands, the epilogue takes the commands output as an input')
            epilog_mutual_group = epilog_group.add_mutually_exclusive_group()
            epilog_mutual_group.add_argument('-e', '--epilogue', help='epilogue as bash commands')
            epilog_mutual_group.add_argument('-E', '--epilogue-suffix', help='epilogue as files with given suffix added to command files, cannot be used with --commands')
            epilog_mutual_group.add_argument('-F', '--epilogue-file', help='epilogue as single file')
            epilog_group.add_argument('-x', '--epilogue-exec', choices=[
             'bash', 'python'], default='python', help='epilogue executable, could be python or bash')
            log_group = parser.add_argument_group('logging', 'logging arguments')
            log_group.add_argument('-v', '--verbose', action='store_true', help='increase verbosity level to debug')
            log_group.add_argument('-g', '--log-dir', action=_DirTypeAction, help="logging directory, by default '%s'" % DEFAULT_LOG_DIR)
            parser.add_argument('-l', '--listen-port', default=0, type=IntRangeType(0, 65535), help='listen port to send cli output')
            parser.add_argument('-z', '--pool-size', default=30, type=IntRangeType(1, 100), help='max number of switches to be run simultaneously')
            parser.add_argument('-o', '--operation-timeout', default=None, type=IntRangeType(10, 3600), help='Operation timeout in seconds')
            extra_commands_group = parser.add_argument_group('extracommands', 'Extra commands')
            initial_cmds = extra_commands_group.add_mutually_exclusive_group()
            initial_cmds.add_argument('-i', '--initial-commands', help="Commands to run before the main commands. Commands should be separated by ';'")
            initial_cmds.add_argument('--initial-commands-file', type=argparse.FileType(), help='Commands file to run before the main commands.')
            final_cmds = extra_commands_group.add_mutually_exclusive_group()
            final_cmds.add_argument('-n', '--final-commands', help="Commands to run after the main commands. Commands should be separated by ';'")
            final_cmds.add_argument('--final-commands-file', type=argparse.FileType(), help='Commands file to run after the main commands.')
            extra_commands_group.add_argument('-p', '--separator', help='Output separator between initial commands, main commands and final commands')
            extra_commands_group.add_argument('-r', '--interactive', action='store_true', help='Force Cli facility  to work in line by line mode')
            extra_commands_group.add_argument('-I', '--interactive-file', type=argparse.FileType(), help='file containing special prompts and their answers')
            args = parser.parse_args()
            if args.directory_content and not args.directory:
                raise argparse.ArgumentError(None, 'Argument -t/--directory-content can be used only with -d/--directory')
            if args.epilogue_suffix and args.commands:
                raise argparse.ArgumentError(None, 'Argument -E/--epilogue-suffix cannot be used with -c/--commands')
        except (argparse.ArgumentError, IOError) as arg_err:
            parser.error(str(arg_err))
            parser.print_usage()
            return

        return args

    def getCommands(self):
        return CommandArgs(self.args)

    def getEpilogue(self):
        return EpilogueArgs(self.args)

    def getInitialCommands(self):
        return ExtraCommandsArgs(self.args.initial_commands, self.args.initial_commands_file)

    def getFinalCommands(self):
        return ExtraCommandsArgs(self.args.final_commands, self.args.final_commands_file)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/arg_parser.pyc
