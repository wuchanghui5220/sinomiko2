# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/logger.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 25, 2015
"""
import logging, os
from providers.common.tools.clifacility import DEFAULT_LOG_DIR, MAIN_LOGGER

class CliLogger(object):
    MAIN_LOGGER_FILE = 'cli-facility.log'
    FORMAT = '%(asctime)s.%(msecs)03d %(name)-5s %(levelname)-7s %(message)s'
    logging.basicConfig(format=FORMAT, datefmt='%Y-%m-%d %H:%M:%S')
    formatter = logging.Formatter(FORMAT, datefmt='%Y-%m-%d %H:%M:%S')

    @classmethod
    def init(cls, log_level=logging.INFO, logging_dir=DEFAULT_LOG_DIR):
        logger = logging.getLogger(MAIN_LOGGER)
        logging.basicConfig()
        logger.setLevel(log_level)
        if not os.path.isdir(logging_dir):
            os.mkdir(logging_dir)
        file_path = os.path.join(logging_dir, cls.MAIN_LOGGER_FILE)
        cls._addFileHandler(logger, log_level, file_path, cls.formatter)

    @classmethod
    def getMainLogger(cls):
        return logging.getLogger(MAIN_LOGGER)

    @classmethod
    def getHostLogger(cls, host):
        logger = logging.getLogger(('.').join((MAIN_LOGGER, host)))
        return logger

    @classmethod
    def _addFileHandler(cls, logger, level, file_path, formatter=None):
        """
        Added a file handler to the given logger.
        @param logger:
            a logger object to add the file handler to.
        @param file_path:
            path to the logging file.
        @param formatter:
            a Format object to add to the handler
        """
        handler = logging.FileHandler(file_path)
        if formatter:
            handler.setFormatter(formatter)
        handler.setLevel(level)
        logger.addHandler(handler)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/logger.pyc
