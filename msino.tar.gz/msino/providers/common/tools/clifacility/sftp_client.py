# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/sftp_client.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Feb 3, 2016
"""
import paramiko
from providers.common.tools.clifacility.host_model import HostModel

class SFTPClient(object):

    def __init__(self, host_data):
        """
        Constructor
        """
        self._hostname = None
        self._username = None
        self._password = None
        self._port = None
        self._transport = None
        self._sftp = None
        self._extractHostData(host_data)
        return

    def _extractHostData(self, host_data):
        self._hostname = host_data.get(HostModel.Columns.HOSTNAME)
        self._username = host_data.get(HostModel.Columns.USERNAME)
        self._password = host_data.get(HostModel.Columns.PASSWORD)
        self._port = host_data.get(HostModel.Columns.PORT)

    def connect(self):
        self._transport = paramiko.Transport((self._hostname, self._port))
        self._transport.connect(username=self._username, password=self._password)
        self._sftp = paramiko.SFTPClient.from_transport(self._transport)

    def upload(self, local, remote):
        return self._sftp.put(local, remote)

    def download(self, remote, local):
        return self._sftp.get(remote, local)

    def close(self):
        """
        Close the connection if it's active
        """
        if self._transport and self._sftp and self._transport.is_active():
            self._sftp.close()
            self._transport.close()
        self._transport = None
        self._sftp = None
        return
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/sftp_client.pyc
