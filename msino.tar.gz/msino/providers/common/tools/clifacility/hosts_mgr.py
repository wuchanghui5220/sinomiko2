# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/hosts_mgr.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 27, 2015
"""
from _functools import partial
import os, re, subprocess32 as subprocess, sys, threading
from winrm.exceptions import WinRMTransportError
from providers.common.tools.clifacility import g_logger
from providers.common.tools.clifacility.cli_result import CliResult, ProcessResult
from providers.common.tools.clifacility.client_factory import ClientFactory
from providers.common.tools.clifacility.exceptions import HostClientError
from providers.common.tools.clifacility.thread_pool import ThreadPool

class HostsMgr(object):
    """
    """

    def __init__(self, hosts_data, commands_db, operation_timeout=None):
        """
        Constructor
        """
        self._hosts_data = hosts_data
        self._commands_db = commands_db
        self._operation_timeout = operation_timeout
        self._hosts = set(self._hosts_data.iterkeys())
        self._results = {}
        self._event = threading.Event()
        self._thread_pool = ThreadPool()
        self._temp_files = set()
        self._lock = threading.Lock()
        self._epilogue_lock = threading.Lock()

    def handleHost(self, host_client, command_obj):
        hostname = None
        try:
            hostname = host_client.getHostname()
            g_logger.info('Handling Host: %s', hostname)
            host_client.connect()
            host_client.execute(command_obj.commands_list, command_obj.initial_commands, command_obj.final_commands, command_obj.separator, command_obj.interactive, command_obj.interactive_params)
            result = host_client.getResult()
            g_logger.debug('Host: %s, out: %s', hostname, result.stdout)
            g_logger.debug('Host: %s, err: %s', hostname, result.stderr)
            return result
        except WinRMTransportError as e:
            msg = re.sub('\\[Errno .*?\\]', '', str(e.message))
            g_logger.warning('Error while handling Host: %s, %s', hostname, msg)
            raise Exception(msg)
        except Exception as e:
            g_logger.warning('Error while handling Host: %s, %s', hostname, str(e))
            raise

        return

    def _runEpilogue(self, host, epilogue_exe, epilogue_script, result):
        self._epilogue_lock.acquire()
        try:
            result.epilogue = ProcessResult()
            g_logger.info('Host: %s, running epilogue: %s(%s)', host, epilogue_script, epilogue_exe)
            penv = os.environ
            penv['_EPILOGUE_DEV'] = host
            if epilogue_exe == 'python':
                args_list = [sys.executable,
                 epilogue_script]
            else:
                args_list = [
                 '/bin/bash',
                 '-C', epilogue_script]
            proc = subprocess.Popen(args_list, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=penv, close_fds=True)
        finally:
            self._epilogue_lock.release()

        stdout, stderr = proc.communicate(result.stdout)
        res = proc.wait()
        result.epilogue.stdout = stdout
        result.epilogue.stderr = stderr
        result.epilogue.exitcode = res
        g_logger.info('Host: %s, epilogue result: %s', host, res)

    def aggregateHostResults(self, host, command_obj, result, success):
        if not success:
            exception_obj = result
            result = CliResult()
            result.stderr = str(exception_obj)
            result.exitcode = 1
            if hasattr(exception_obj, 'errno'):
                result.exitcode = exception_obj.errno
                if not result.exitcode:
                    result.exitcode = 1
        g_logger.info('Host: %s, exit-code: %s', host, result.exitcode)
        if success and result.exitcode == 0 and command_obj.epilogue_script:
            self._runEpilogue(host, command_obj.epilogue_exe, command_obj.epilogue_script, result)
        self._setHostResult(host, result)
        if not self._hosts:
            self._cleanup()
            self._event.set()

    def _cleanup(self):
        for file_name in self._temp_files:
            try:
                os.unlink(file_name)
            except Exception as e:
                g_logger.error("Could not remove temporary file '%s', %s", file_name, str(e))

    def waitForResults(self):
        while self._hosts:
            timeout = None
            if self._operation_timeout:
                timeout = self._operation_timeout / 2
            self._event.wait(timeout)
            if self._hosts:
                self._checkForTimeout()

        return self._results

    def _checkForTimeout(self):
        killed_list = self._thread_pool.killTimedoutThreads(self._operation_timeout)
        if killed_list:
            g_logger.warning('Timeout operation for Host(s): %s', (',').join(killed_list))
        for host in killed_list:
            result = CliResult()
            result.stderr = 'Timeout while communicating with: %s' % host
            result.exitcode = 1
            self._setHostResult(host, result)

    def _setHostResult(self, host, result):
        self._lock.acquire()
        try:
            self._results[host] = result
            self._hosts.discard(host)
        finally:
            self._lock.release()

    def manageHosts(self):
        for host, host_data in self._hosts_data.iteritems():
            host_client = ClientFactory.createHostClient(host_data)
            if not host_client:
                raise HostClientError('cannot manage host %s, no driver found' % host)
            if self._operation_timeout:
                host_client.setOperationTimeout(self._operation_timeout)
            command_obj = self._commands_db.getCommandObj(host)
            if command_obj.temp_epilogue:
                self._temp_files.add(command_obj.epilogue_script)
            result_callback = partial(self.aggregateHostResults, host, command_obj)
            self._thread_pool.callThread(host, result_callback, self.handleHost, host_client, command_obj)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/hosts_mgr.pyc
