# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/results_listener.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 27, 2015
"""
from multiprocessing.connection import Client
from providers.common.tools.clifacility import g_logger

class ResultsListener(object):
    """
    """

    def __init__(self, port):
        """
        """
        self.client = None
        if port:
            address = (
             'localhost', port)
            try:
                self.client = Client(address)
            except Exception as e:
                g_logger.error('Failed to connect to server on port: %s error: %s', port, str(e))
                self.client = None

        return

    def sendResult(self, result):
        g_logger.info('Result is ready...')
        if self.client:
            try:
                g_logger.info('Sending result to client...')
                self.client.send(result)
            except Exception as e:
                g_logger.error('Failed to send result to server: %s', str(e))
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/results_listener.pyc
