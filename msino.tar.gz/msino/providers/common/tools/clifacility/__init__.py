# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/__init__.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.
"""
import logging
MAIN_LOGGER = 'cli-facility'
DEFAULT_LOG_DIR = '/var/log/clifacility'
g_logger = logging.getLogger(MAIN_LOGGER)

class CommandType:
    COMMAND = 0
    FILE = 1
    DIR_HOST = 2
    DIR_TYPE = 3


class ClientTypes:
    MLNXOS = 'mlnxos_switch'
    JUNIPER = 'juniper_switch'
    ARISTA = 'arista_switch'
    BROCADE = 'brocade_switch'
    HP = 'hp_switch'
    H3C = 'h3c_switch'
    CISCO = 'cisco_switch'
    OTHER_SWITCH = 'other_switch'
    CUMULUS = 'cumulus_switch'
    LINUX = 'linux_host'
    NUTANIX = 'nutanix_host'
    WINDOWS = 'windows_host'
    ESX = 'esx_host'
    OTHER_HOST = 'other_host'
    SUPPORTED_CLIENT_TYPES = (
     MLNXOS, JUNIPER, ARISTA, CISCO, OTHER_SWITCH,
     LINUX, WINDOWS, ESX, OTHER_HOST, HP, H3C,
     BROCADE, NUTANIX, CUMULUS)


def singleton(cls):
    obj = cls()
    cls.__new__ = staticmethod(lambda cls: obj)
    try:
        del cls.__init__
    except AttributeError:
        pass

    return cls
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/__init__.pyc
