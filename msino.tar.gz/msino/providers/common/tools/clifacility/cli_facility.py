# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/cli_facility.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 24, 2015
"""
import sys
from providers.common.tools.clifacility.host_model import HostModel
from providers.common.tools.clifacility.commands_db import CommandsDb
from providers.common.tools.clifacility.hosts_mgr import HostsMgr
from providers.common.tools.clifacility.arg_parser import CliArgParser
from providers.common.tools.clifacility.results_listener import ResultsListener
from providers.common.tools.clifacility.thread_pool import ThreadPool
import logging
from providers.common.tools.clifacility import DEFAULT_LOG_DIR, g_logger
from providers.common.tools.clifacility.logger import CliLogger
from providers.common.tools.clifacility.exceptions import HostModelError

class CliFacility(object):

    def __init__(self, hosts_file, commands_arg, epilogue_arg, pool_size, initial_commands_arg, final_commands_arg, separator, verbose, listen_port, operation_timeout, interactive, interactive_file):
        self._pool_size = pool_size
        self._verbose = verbose
        self._hosts_data = {}
        self._listen_port = listen_port
        self._operation_timeout = operation_timeout
        self._loadHosts(hosts_file)
        self._commands_db = CommandsDb(self._hosts_data, commands_arg, initial_commands_arg, final_commands_arg, separator, epilogue_arg, interactive, interactive_file)
        self._thread_pool = ThreadPool()

    def _loadHosts(self, data_file):
        data_model = HostModel()
        data_model.load(data_file)
        self._hosts_data = data_model.getData()
        if not self._hosts_data:
            raise HostModelError('No Devices found!')

    def run(self):
        try:
            g_logger.info('running : %s', (' ').join(sys.argv))
            self._thread_pool.start(self._pool_size)
            results_listener = ResultsListener(self._listen_port)
            hosts_mgr = HostsMgr(self._hosts_data, self._commands_db, self._operation_timeout)
            hosts_mgr.manageHosts()
            results = hosts_mgr.waitForResults()
            results_listener.sendResult(results)
        finally:
            self._thread_pool.stop()

        return 0


def main():
    try:
        arg_parser = CliArgParser()
        if not arg_parser.args:
            return 1
        args = arg_parser.args
        log_level = logging.INFO
        if args.verbose:
            log_level = logging.DEBUG
        logging_dir = args.log_dir or DEFAULT_LOG_DIR
        CliLogger.init(log_level, logging_dir)
        tool = CliFacility(args.hosts, arg_parser.getCommands(), arg_parser.getEpilogue(), args.pool_size, arg_parser.getInitialCommands(), arg_parser.getFinalCommands(), args.separator, args.verbose, args.listen_port, args.operation_timeout, args.interactive, args.interactive_file)
        res = tool.run()
    except Exception as e:
        print '-E-', "Got Error '%s'" % str(e)
        res = 1

    return res


if __name__ == '__main__':
    sys.exit(main())
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/cli_facility.pyc
