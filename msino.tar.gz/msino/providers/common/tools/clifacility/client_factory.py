# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/client_factory.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 24, 2015
"""
from providers.common.tools.clifacility import ClientTypes
from providers.common.tools.clifacility.host_client import MlnxSwitch, CiscoSwitch, AristaSwitch, JuniperSwitch, LinuxHost, WindowsHost, HpSwitch, H3cSwitch, BrocadeSwitch, NutanixHost, CumulusSwitch
from providers.common.tools.clifacility.host_model import HostModel

class ClientFactory(object):
    """
    """
    HOST_MAPPING = {ClientTypes.MLNXOS: MlnxSwitch, 
       ClientTypes.JUNIPER: JuniperSwitch, 
       ClientTypes.ARISTA: AristaSwitch, 
       ClientTypes.BROCADE: BrocadeSwitch, 
       ClientTypes.HP: HpSwitch, 
       ClientTypes.H3C: H3cSwitch, 
       ClientTypes.CISCO: CiscoSwitch, 
       ClientTypes.CUMULUS: CumulusSwitch, 
       ClientTypes.LINUX: LinuxHost, 
       ClientTypes.NUTANIX: NutanixHost, 
       ClientTypes.WINDOWS: WindowsHost}

    @classmethod
    def createHostClient(cls, host_data):
        host_type = host_data.get(HostModel.Columns.SYSTYPE)
        if host_type:
            host_class = cls.HOST_MAPPING.get(host_type)
            if host_class:
                return host_class(host_data)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/client_factory.pyc
