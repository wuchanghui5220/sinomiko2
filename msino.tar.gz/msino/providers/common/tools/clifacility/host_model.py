# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/host_model.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 19, 2015
"""
import csv, re
from providers.common.tools.clifacility import ClientTypes
from providers.common.tools.clifacility.exceptions import HostModelError

class HostModelValidatir(object):
    HOSTNAME_REGEX = re.compile('^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])(\\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9]))*|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3})$')
    MAX_PORT = 65535

    @classmethod
    def validateSysType(cls, sys_type):
        if sys_type not in ClientTypes.SUPPORTED_CLIENT_TYPES:
            raise HostModelError('Unsupported system type: %s.\nsupported types are: %s' % (
             sys_type, str(ClientTypes.SUPPORTED_CLIENT_TYPES)))
        return sys_type

    @classmethod
    def validateHostName(cls, host_name):
        if not cls.HOSTNAME_REGEX.match(host_name):
            raise HostModelError("Invalid host-name '%s'" % host_name)
        return host_name

    @classmethod
    def validatePort(cls, port):
        try:
            port = int(port)
        except:
            raise HostModelError("Invalid port number '%s', not an integer" % port)

        if port < 0 or port > cls.MAX_PORT:
            raise HostModelError("Invalid port number '%s', port is out of range" % port)
        return port

    @classmethod
    def validateTimeout(cls, timeout):
        try:
            timeout = int(timeout)
        except:
            raise HostModelError("Invalid timeout '%s', not an integer" % timeout)

        if timeout <= 0:
            raise HostModelError("Invalid timeout '%s', timeout must be greater than 0" % timeout)
        return timeout


class HostModel(object):

    class Columns:
        HOSTNAME = 'Hostname'
        SYSTYPE = 'SysType'
        USERNAME = 'Username'
        PASSWORD = 'Password'
        PORT = 'Port'
        TIMEOUT = 'Timeout'
        AUTHENTICATION = 'Authentication'
        DEFAULT_COLUMNS = [
         HOSTNAME, SYSTYPE, USERNAME, PASSWORD, PORT,
         TIMEOUT, AUTHENTICATION]

    _validators = {Columns.SYSTYPE: HostModelValidatir.validateSysType, 
       Columns.HOSTNAME: HostModelValidatir.validateHostName, 
       Columns.PORT: HostModelValidatir.validatePort, 
       Columns.TIMEOUT: HostModelValidatir.validateTimeout}

    def __init__(self, columns=Columns.DEFAULT_COLUMNS, primary_key=Columns.HOSTNAME):
        self._curr_row = 0
        self._data = {}
        self._columns = columns
        self._primary_key = primary_key
        if self._primary_key not in self._columns:
            raise HostModelError("primary key '%s' is not part of the given columns" % self._primary_key)

    def load(self, csv_file):
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            row_data = {}
            for key, value in row.iteritems():
                key = key.strip()
                if value:
                    value = value.strip()
                row_data[key] = value

            self.add(row_data)

    def add(self, row_data):
        for column in self._columns:
            if column not in row_data:
                raise HostModelError("Missing '%s' column (row: %s)." % (
                 column, self._curr_row))
            if column in self._validators:
                val = self._validators[column](row_data[column])
                row_data[column] = val

        primary_key = row_data.get(self._primary_key)
        if primary_key in self._data:
            raise HostModelError("Duplicate primary key '%s' (row: %s)." % (
             primary_key, self._curr_row))
        self._data[primary_key] = row_data
        self._curr_row += 1

    def save(self, data_file):
        with open(data_file, 'w') as (csv_file):
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(self._columns)
            for row_data in self._data.itervalues():
                row_items = [ row_data[column] for column in self._columns ]
                csv_writer.writerow(row_items)

    def getData(self):
        return self._data
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/host_model.pyc
