# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/host_client.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 24, 2015
"""
import re, socket, time, paramiko
from paramiko.ssh_exception import AuthenticationException
from providers.common.tools.clifacility import g_logger
from providers.common.tools.clifacility.cli_result import CliResult
from providers.common.tools.clifacility.exceptions import HostClientError, KerberosError
from providers.common.tools.clifacility.host_model import HostModel
from providers.common.tools.clifacility.kerberos_ticket import KerberosTicket
from providers.common.tools.clifacility.winrm_wrapper import WHSession

class HostClient(object):
    AUTH_BASIC = 0
    AUTH_KERBEROS = 1
    _builtin_initial_commands = []
    _builtin_finalization_commands = []

    def __init__(self, host_data):
        """
        Constructor
        """
        self._hostname = None
        self._username = None
        self._password = None
        self._port = None
        self._timeout = None
        self._operation_timeout = 3600
        self._auth = None
        self._result = CliResult()
        self._extractHostData(host_data)
        self._connetction_timeout = None
        return

    def _extractHostData(self, host_data):
        self._hostname = host_data.get(HostModel.Columns.HOSTNAME)
        self._username = host_data.get(HostModel.Columns.USERNAME)
        self._password = host_data.get(HostModel.Columns.PASSWORD)
        self._port = host_data.get(HostModel.Columns.PORT)
        self._timeout = host_data.get(HostModel.Columns.TIMEOUT)
        self._auth = host_data.get(HostModel.Columns.AUTHENTICATION)

    def connect(self):
        raise NotImplementedError('%s.%s is not implemented!', self.__class__.__name__, 'connect')

    def execute(self, commands, initial_commands=[], final_commands=[], separator=None, interactive=False, interactive_params=None):
        raise NotImplementedError('%s.%s is not implemented!', self.__class__.__name__, 'execute')

    def setOperationTimeout(self, tout):
        self._operation_timeout = tout

    def setConnectionTimeout(self, tout):
        self._connetction_timeout = tout

    def getHostname(self):
        return self._hostname

    def getResult(self):
        return self._result

    def _getAllCommands(self, commands, initial_commands=[], final_commands=[]):
        all_commands = []
        all_commands.extend(self._builtin_initial_commands)
        all_commands.extend(initial_commands)
        all_commands.extend(commands)
        all_commands.extend(final_commands)
        all_commands.extend(self._builtin_finalization_commands)
        return all_commands


class SshHostClient(HostClient):
    """
    """
    RECV_READY_INTERVAL = 0.5
    RECV_BUFFER_INTERVAL = 0.05
    RECV_BUFFER_SIZE = 10000
    _RECONNECT_WAIT_AFTER_RELOAD = 30
    _DISCONNECT_WAIT_AFTER_RELOAD = 2
    _WAIT_BEFORE_RELOAD = 1
    _RELOAD_WAIT_INTERVAL = 10
    _prompt_suffixes = []
    _error_regex = None
    _exec_mode = False
    _reload_commands = []

    def __init__(self, host_data):
        """
        Constructor
        """
        super(SshHostClient, self).__init__(host_data)
        self._ssh_client = None
        self._ssh_channel = None
        self._interactive_params = None
        return

    def connect(self):
        self._ssh_client = paramiko.SSHClient()
        self._ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            self._ssh_client.connect(self._hostname, port=self._port, username=self._username, password=self._password, timeout=self._timeout, look_for_keys=False)
        except Exception as e:
            if isinstance(e, AuthenticationException):
                raise AuthenticationException('SSH Authentication failure: please check device credentials')
            raise

    def _openShell(self):
        self._ssh_channel = self._ssh_client.invoke_shell()
        self._ssh_channel.settimeout(self._operation_timeout)
        self._recvInitialPrompt()

    def _invokeShellCommands(self, commands, initial_commands, final_commands, separator, interactive_params):
        if not self._ssh_client:
            raise HostClientError("No connection was established with host'%s'" % self._hostname)
        if not commands:
            return
        self._openShell()
        all_commands = self._getAllCommands(commands, initial_commands, final_commands)
        start_concat_output_pos = len(self._builtin_initial_commands)
        end_concat_output_pos = len(all_commands) - len(self._builtin_finalization_commands)
        separator_pos_list = []
        if initial_commands:
            separator_pos_list.append(start_concat_output_pos + len(initial_commands))
        if final_commands:
            separator_pos_list.append(end_concat_output_pos - len(final_commands))
        for index, command in enumerate(all_commands):
            sts, output = self._execSingleCommand(command)
            if index in separator_pos_list and separator is not None:
                self._result.stdout += separator
            if not sts:
                self._result.exitcode = 1
                self._result.stderr = output
                break
            if index >= start_concat_output_pos and index < end_concat_output_pos:
                self._result.stdout += output

        self._ssh_channel.close()
        return

    def _hidePasswords(self, command, output):
        return output

    def _execSingleCommand(self, command):
        if command in self._reload_commands:
            return self._sendReload(command)
        self._ssh_channel.send('%s\n' % command)
        output = self._recv()
        errors = self._checkErrors(output)
        output = self._hidePasswords(command, output)
        return (
         not errors, output)

    def _sleep(self, interval, timeout):
        time.sleep(interval)
        return timeout - interval

    def _sendReload(self, command):
        g_logger.info("reload command '%s' initiated on '%s'", command, self._hostname)
        timeout = self._operation_timeout
        timeout = self._sleep(self._WAIT_BEFORE_RELOAD, timeout)
        g_logger.info("sending reload command '%s' '%s'", command, self._hostname)
        self._ssh_channel.send('%s\n' % command)
        output = '%s\n' % command
        timeout = self._sleep(self._DISCONNECT_WAIT_AFTER_RELOAD, timeout)
        self._ssh_channel.close()
        g_logger.info("'%s': closing connection to '%s' and try to reconnect", command, self._hostname)
        timeout = self._sleep(self._RECONNECT_WAIT_AFTER_RELOAD, timeout)
        connected = False
        while timeout > 0:
            try:
                self.connect()
                connected = True
                break
            except Exception:
                timeout = self._sleep(self._RELOAD_WAIT_INTERVAL, timeout)

        if connected:
            g_logger.info("'%s': connection restored to '%s'", command, self._hostname)
            self._openShell()
            for command in self._builtin_initial_commands:
                self._execSingleCommand(command)

            output += 'reload done successfully\n'
        else:
            g_logger.info("'%s': restoring connection to '%s'- timeout", command, self._hostname)
            output += 'Error: timeout while waiting for reload end!\n'
        g_logger.info("reload command on '%s' ended, status: %s", self._hostname, connected)
        return (
         connected, output)

    def _getSeparatorCommands(self, separator):
        return []

    def _execCommands(self, commands, initial_commands, final_commands, separator, interactive_params):
        if not commands:
            return
        all_commands = []
        all_commands.extend(self._builtin_initial_commands)
        if initial_commands:
            all_commands.extend(initial_commands)
            if separator:
                all_commands.extend(self._getSeparatorCommands(separator))
        all_commands.extend(commands)
        if final_commands:
            if separator:
                all_commands.extend(self._getSeparatorCommands(separator))
            all_commands.extend(final_commands)
        all_commands.extend(self._builtin_finalization_commands)
        self._ssh_channel = self._ssh_client.get_transport().open_session()
        self._ssh_channel.settimeout(self._operation_timeout)
        command_str = ('\n').join(all_commands)
        self._ssh_channel.exec_command(command_str)
        stdout = self._ssh_channel.makefile('r', -1)
        self._result.stdout += stdout.read()
        stderr = self._ssh_channel.makefile_stderr('r', -1)
        self._result.stderr += stderr.read()
        self._result.exitcode = self._ssh_channel.recv_exit_status()
        self._verifyConnection()
        self._ssh_channel.close()

    def execute(self, commands, initial_commands=[], final_commands=[], separator=None, interactive=False, interactive_params=None):
        self._interactive_params = interactive_params or {}
        try:
            if self._exec_mode and not interactive:
                return self._execCommands(commands, initial_commands, final_commands, separator, interactive_params)
            return self._invokeShellCommands(commands, initial_commands, final_commands, separator, interactive_params)
        except socket.timeout:
            raise HostClientError('Timeout while receiving data from :%s' % self._hostname)

    def _recvInitialPrompt(self):
        return self._recv()

    def _verifyConnection(self):
        transport = self._ssh_client.get_transport()
        if not transport or not transport.is_active() or not transport.is_alive():
            raise HostClientError("device '%s' has disconnected unexpectedly!" % self._hostname)
        try:
            transport.send_ignore()
        except EOFError:
            raise HostClientError("device '%s' disconnected!" % self._hostname)

    def _recv(self, check_prompt=True, wait=True):
        output = u''
        if not self._ssh_channel:
            raise HostClientError("No channel was opened with host'%s'" % self._hostname)
        sleep_time = 0
        while not self._ssh_channel.recv_ready():
            self._verifyConnection()
            if not wait:
                raise HostClientError("No data to receive for host'%s'" % self._hostname)
            time.sleep(self.RECV_READY_INTERVAL)
            self._verifyConnection()
            sleep_time += self.RECV_READY_INTERVAL
            if sleep_time > self._operation_timeout:
                raise socket.timeout()

        is_prompt = False
        while not is_prompt:
            self._verifyConnection()
            recv_out = self._ssh_channel.recv(self.RECV_BUFFER_SIZE)
            recv_out = ('').join([ c if ord(c) < 128 else '?' for c in recv_out ])
            output = output + recv_out
            if not check_prompt:
                break
            for suffix, resp in self._interactive_params.iteritems():
                if output.endswith(suffix):
                    g_logger.info('got interactive prompt: %s, response: %s', suffix, resp)
                    if resp == '@DEVICE_PWD@':
                        resp = self._password
                    else:
                        if resp == '@DEVICE_USR@':
                            resp = self._username
                    self._ssh_channel.send('%s\n' % resp)
                    output = output + self._recv(check_prompt, wait)
                    return output

            for suffix in self._prompt_suffixes:
                if output.endswith(suffix):
                    is_prompt = True

            if not is_prompt:
                time.sleep(self.RECV_BUFFER_INTERVAL)

        if not check_prompt:
            return output
        sep = '\n'
        rpos = output.rfind('\r')
        npos = output.rfind('\n')
        if rpos > npos:
            sep = '\r'
        output_lines = output.rsplit(sep, 1)
        return output_lines[0]

    def _checkErrors(self, output):
        if self._error_regex and output:
            match = self._error_regex.search(output)
            return match is not None
        return False


class MlnxSwitch(SshHostClient):
    _prompt_suffixes = [
     '# ', '> ', '# \x08 ', '> \x08 ', '#  \x08', '>  \x08']
    _error_regex = re.compile('\\A%|\\r\\n%|\\n%')
    _builtin_initial_commands = ['no cli session paging enable', 'enable',
     'configure terminal']
    RELOAD_COMMAND = 'reload noconfirm'
    RELOAD_FORCE_COMMAND = 'reload force'
    _reload_commands = set([RELOAD_COMMAND, RELOAD_FORCE_COMMAND])
    _password_commands_regex = re.compile('(.*)password ([\\w]+)(.*)')

    def _hidePasswords(self, command, output):
        if self._password_commands_regex.search(command):
            return self._password_commands_regex.sub('\\1password ****\\3', output)
        return super(MlnxSwitch, self)._hidePasswords(command, output)


class CiscoSwitch(SshHostClient):
    _prompt_suffixes = [
     '# ']
    _error_regex = re.compile('\\A%|\\r\\n%|\\n%|\\AERROR:|\\nERROR:|\\r\\nERROR:|Auth passphrase specified is not strong enough:|Unable to perform the action')
    _builtin_initial_commands = [
     'terminal length 0', 'configure terminal']
    _reload_commands = set(['reload force'])


class JuniperSwitch(SshHostClient):
    _prompt_suffixes = [
     '# ', '> ']
    _error_regex = re.compile('(\\A\\s*\\^)|(\\r\\n\\s*\\^)|(\\n\\s*\\^)')
    _builtin_initial_commands = ['set cli screen-length 0']


class AristaSwitch(SshHostClient):
    """
    This class is implements Arista switch
    """
    _prompt_suffixes = [
     '#', '>']
    _error_regex = re.compile('\\A%|\\r\\n%|\\n%')
    _builtin_initial_commands = [
     'terminal length 0', 'enable', 'configure terminal']


class HpSwitch(SshHostClient):
    """
    This class is implements Hp switch
    """
    _prompt_suffixes = [
     '# ', 'continue']
    _error_regex = re.compile('Invalid input:')
    _builtin_initial_commands = ['\n', 'configure', 'no page']


class BrocadeSwitch(SshHostClient):
    """
    This class is implements Brocade switch
    """
    _prompt_suffixes = [
     '# ']
    _error_regex = re.compile('Invalid input parameters.|\\n*command not found')
    _builtin_initial_commands = ['terminal length 0']


class H3cSwitch(SshHostClient):
    """
    This class is implements Hp H3c switch
    """
    _prompt_suffixes = [
     '<HP>']
    _error_regex = re.compile('Invalid input:')
    _builtin_initial_commands = ['screen-length disable']


class LinuxHost(SshHostClient):
    """
    This class is implements Linux host
    """
    _exec_mode = True
    _prompt_suffixes = ['# ', '#', '> ', '>', '$', '$ ']
    _reload_commands = ['reboot', 'sudo reboot', 'sudo reboot -f']

    def _getSeparatorCommands(self, separator):
        cmds = []
        if separator:
            cmds.append('echo -n "%s"' % separator)
        return cmds


class CumulusSwitch(LinuxHost):
    _error_regex = re.compile('\\AError:|\\nError:|\\r\\nError:')


class NutanixHost(LinuxHost):
    """
    This class is implements Nutanix host
    """
    pass


class WindowsHost(HostClient):
    """
    This class is implements Windows host
    """
    run_by_block = True
    _builtin_initial_commands = [
     '$pshost = get-host',
     '$pswindow = $pshost.ui.rawui',
     '$newsize = $pswindow.buffersize',
     '$newsize.height = 3000',
     '$newsize.width = 150',
     '$pswindow.buffersize = $newsize',
     '$newsize = $pswindow.windowsize',
     '$newsize.height = 50',
     '$newsize.width = 150',
     '$pswindow.windowsize = $newsize']

    def __init__(self, host_data):
        super(WindowsHost, self).__init__(host_data)
        self._session = None
        return

    def connect(self):
        transport = 'kerberos'
        auth = (self._username, self._password)
        if int(self._auth) == self.AUTH_KERBEROS:
            try:
                krb = KerberosTicket(self._username, self._password)
            except Exception:
                raise KerberosError('Invalid Kerberos Realm')

            result = krb.setTicket()
            if result.returncode != 0:
                raise KerberosError('%s' % str(result.stderr))
        else:
            if int(self._auth) == self.AUTH_BASIC:
                transport = 'plaintext'
        self._session = WHSession(self._hostname, auth, transport, self._operation_timeout, self._connetction_timeout)

    def _runPowerShell(self, cmd):
        ps_script = ('\n        {0}\n        ').format(cmd)
        rc = self._session.run_ps(ps_script)
        self._result.stdout += rc.std_out.strip()
        if rc.status_code != 0:
            self._result.stderr += rc.std_err.strip()
        self._result.exitcode = rc.status_code
        return rc.status_code

    def _runWinRmByLine(self, commands):
        for cmd in commands:
            rc = self._runPowerShell(cmd)
            if rc != 0:
                break

        return rc

    def _runWinRmByBlock(self, commands):
        cmd = ('\r\n').join(commands)
        rc = self._runPowerShell(cmd)
        return rc

    def execute(self, commands, initial_commands=[], final_commands=[], separator=None, interactive=False, interactive_params=None):
        all_commands = self._getAllCommands(commands, initial_commands, final_commands)
        if self.run_by_block:
            return self._runWinRmByBlock(all_commands)
        return self._runWinRmByLine(all_commands)
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/host_client.pyc
