# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/commands_db.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Aug 26, 2015
"""
import os
from providers.common.tools.clifacility.host_model import HostModel
from providers.common.tools.clifacility import CommandType
import tempfile, errno, json

class InvalidCommandsList(Exception):
    pass


class CommandsDb(object):
    """
    """

    class CommandObj(object):

        def __init__(self, commands_list, initial_commands, final_commands, separator, epilogue_script=None, epilogue_exe=None, temp_epilogue=True, interactive=False, interactive_params=None):
            self.commands_list = commands_list
            self.initial_commands = initial_commands
            self.final_commands = final_commands
            self.separator = separator
            self.epilogue_script = epilogue_script
            self.epilogue_exe = epilogue_exe
            self.temp_epilogue = temp_epilogue
            self.interactive = interactive
            self.interactive_params = interactive_params

    def __init__(self, hosts_data, commands_arg, initial_commands_arg, final_commands_arg, separator, epilogue_arg, interactive, interactive_file):
        """
        Constructor
        """
        self._commands_mapping = {}
        self._loadCommands(hosts_data, commands_arg.command_type, commands_arg.command_value, initial_commands_arg, final_commands_arg, separator, epilogue_arg, interactive, interactive_file)

    def _getFileContent(self, file_p):
        cmd_list = []
        for line in file_p:
            line = line.strip()
            if line:
                cmd_list.append(line)

        if not cmd_list:
            raise InvalidCommandsList('Cannot run commands: Empty Commands List!')
        return cmd_list

    def _getInteractiveParams(self, file_p):
        if not file_p:
            return
        try:
            return json.load(file_p)
        except:
            raise InvalidCommandsList('Faile to load interactive params file')

    def _getEpilogueScript(self, file_path, suffix):
        epilog_script = file_path + suffix
        if not os.path.isfile(epilog_script):
            err_no = errno.ENOENT
            str_error = os.strerror(err_no)
            raise OSError(err_no, str_error, epilog_script)
        return epilog_script

    def _getExtraCommands(self, extra_commands_arg):
        if extra_commands_arg.is_file:
            return self._getFileContent(extra_commands_arg.extra_commands)
        if extra_commands_arg.extra_commands:
            return extra_commands_arg.extra_commands.split(';')
        return []

    def _loadCommands(self, hosts_data, commands_type, commands_value, initial_commands_arg, final_commands_arg, separator, epilogue_arg, interactive, interactive_file):
        epilog_exe = epilogue_arg.executable
        epilogue = epilogue_arg.epilogue
        is_suffix = epilogue_arg.is_suffix
        is_epilogue_file = epilogue_arg.is_file
        epilog_script = None
        is_temp_script = False
        interactive_params = self._getInteractiveParams(interactive_file)
        initial_commands = self._getExtraCommands(initial_commands_arg)
        final_commands = self._getExtraCommands(final_commands_arg)
        if epilogue and not is_suffix:
            if not is_epilogue_file:
                epilog_script = tempfile.mktemp()
                is_temp_script = True
                with open(epilog_script, 'w') as (fp):
                    fp.write(epilogue)
            else:
                epilog_script = epilogue
        if commands_type == CommandType.COMMAND:
            commands_list = commands_value.split(';')
            for host in hosts_data:
                self._commands_mapping[host] = self.CommandObj(commands_list, initial_commands, final_commands, separator, epilog_script, epilog_exe, is_temp_script, interactive, interactive_params)

        else:
            if commands_type == CommandType.FILE:
                file_p = commands_value
                content = self._getFileContent(file_p)
                if epilogue and is_suffix:
                    epilog_script = self._getEpilogueScript(file_p.name, epilogue)
                file_p.close()
                for host in hosts_data:
                    self._commands_mapping[host] = self.CommandObj(content, initial_commands, final_commands, separator, epilog_script, epilog_exe, is_temp_script, interactive, interactive_params)

            else:
                if commands_type == CommandType.DIR_HOST:
                    for host in hosts_data:
                        file_path = os.path.join(commands_value, host)
                        with open(file_path) as (fp):
                            content = self._getFileContent(fp)
                        if epilogue and is_suffix:
                            epilog_script = self._getEpilogueScript(file_path, epilogue)
                        self._commands_mapping[host] = self.CommandObj(content, initial_commands, final_commands, separator, epilog_script, epilog_exe, is_temp_script, interactive, interactive_params)

                else:
                    if commands_type == CommandType.DIR_TYPE:
                        type_mapping = {}
                        for host, host_data in hosts_data.iteritems():
                            sys_type = host_data[HostModel.Columns.SYSTYPE]
                            if sys_type not in type_mapping:
                                file_path = os.path.join(commands_value, sys_type)
                                with open(file_path) as (fp):
                                    content = self._getFileContent(fp)
                                if epilogue and is_suffix:
                                    epilog_script = self._getEpilogueScript(file_path, epilogue)
                                type_mapping[sys_type] = (content, epilog_script)
                            content, epilog_script = type_mapping[sys_type]
                            self._commands_mapping[host] = self.CommandObj(content, initial_commands, final_commands, separator, epilog_script, epilog_exe, is_temp_script, interactive, interactive_params)

        return

    def getCommandObj(self, host):
        return self._commands_mapping[host]
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/commands_db.pyc
