# uncompyle6 version 3.2.6
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 20 2015, 02:00:19) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-4)]
# Embedded file name: /opt/neo/providers/common/bin/providers/common/tools/clifacility/winrm_wrapper.py
# Compiled at: 2018-08-15 00:30:34
"""
@copyright:
    Copyright (C) Mellanox Technologies Ltd. 2014-2017. ALL RIGHTS RESERVED.

    This software product is a proprietary product of Mellanox Technologies
    Ltd. (the "Company") and all right, title, and interest in and to the
    software product, including all associated intellectual property rights,
    are and shall remain exclusively with the Company.

    This software product is governed by the End User License Agreement
    provided with the software product.

@author: Samer Deeb
@date:   Dec 17, 2015
"""
from winrm.transport import HttpPlaintext, HttpKerberos
from providers.common.tools.clifacility.exceptions import HostClientError
from winrm.protocol import Protocol
import winrm
from datetime import timedelta
from isodate.isoduration import duration_isoformat

class KRTransport(HttpKerberos):

    def __init__(self, target, endpoint, realm=None, service='HTTP', keytab=None, server_cert_validation='validate', connetction_timeout=None):
        super(KRTransport, self).__init__(endpoint, realm=realm, service=service, keytab=keytab, server_cert_validation=server_cert_validation)
        self.target = target
        if connetction_timeout is not None:
            self.timeout = connetction_timeout
        return

    def send_message(self, message):
        response_text = super(KRTransport, self).send_message(message)
        if 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive' in message and 'Code="2150858793"' in response_text:
            raise HostClientError('Timeout while receiving data from :%s' % self.target)
        return response_text


class WHTransport(HttpPlaintext):

    def __init__(self, target, endpoint, username='', password='', disable_sspi=True, basic_auth_only=True, connetction_timeout=None):
        super(WHTransport, self).__init__(endpoint, username=username, password=password, disable_sspi=disable_sspi, basic_auth_only=basic_auth_only)
        self.target = target
        if connetction_timeout is not None:
            self.timeout = connetction_timeout
        return

    def send_message(self, message):
        response_text = super(WHTransport, self).send_message(message)
        if 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive' in message and 'Code="2150858793"' in response_text:
            raise HostClientError('Timeout while receiving data from :%s' % self.target)
        return response_text


class WHProtocol(Protocol):

    def __init__(self, target, endpoint, transport='plaintext', username=None, password=None, realm=None, service=None, keytab=None, ca_trust_path=None, cert_pem=None, cert_key_pem=None, connetction_timeout=None):
        super(WHProtocol, self).__init__(endpoint, transport=transport, username=username, password=password, realm=realm, service=service, keytab=keytab, ca_trust_path=ca_trust_path, cert_pem=cert_pem, cert_key_pem=cert_key_pem)
        if transport == 'plaintext':
            self.transport = WHTransport(target, endpoint, username, password, connetction_timeout=connetction_timeout)
        else:
            user, realm = username.split('@')
            self.transport = KRTransport(target, endpoint, realm, connetction_timeout=connetction_timeout)


class WHSession(winrm.Session):

    def __init__(self, target, auth, transport, operation_timeout, connetction_timeout=None):
        self.operation_timeout = duration_isoformat(timedelta(seconds=operation_timeout))
        username, password = auth
        self.url = self._build_url(target, 'plaintext')
        self.protocol = WHProtocol(target, self.url, transport, username=username, password=password, connetction_timeout=connetction_timeout)

    def run_cmd(self, command, args=()):
        shell_id = self.protocol.open_shell(idle_timeout=self.operation_timeout)
        command_id = self.protocol.run_command(shell_id, command, args)
        rs = winrm.Response(self.protocol.get_command_output(shell_id, command_id))
        self.protocol.cleanup_command(shell_id, command_id)
        self.protocol.close_shell(shell_id)
        return rs
# okay decompiling /opt/neo//providers/common/bin/providers/common/tools/clifacility/winrm_wrapper.pyc
